## kube生成秘钥文件使用手册

### 安装 cfssl、cfssljson

### 执行

```
sh create_kubessl.sh
```
