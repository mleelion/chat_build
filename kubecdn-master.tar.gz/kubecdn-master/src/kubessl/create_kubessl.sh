#!/bin/bash

# ls
# ca-config.json ca-csr.json

# 生成证书 ca.csr  ca-key.pem  ca.pem
cfssl gencert -initca ca-csr.json | cfssljson -bare ca

#由kubernetes-csr.json 生成 kubernetes 证书 kubernetes.csr kubernetes-key.pem  kubernetes.pem 
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=kubernetes kubernetes-csr.json | cfssljson -bare kubernetes

# admin-csr.json 生成 admin 证书 
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=kubernetes admin-csr.json | cfssljson -bare admin

# 创建kube-controller-manager客户端证书和私钥
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=kubernetes controller-manager-csr.json | cfssljson -bare controller-manager

# 创建kube-scheduler客户端证书和私钥
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=kubernetes scheduler-csr.json | cfssljson -bare scheduler

# 创建kube-proxy客户端证书和私钥
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=kubernetes  kube-proxy-csr.json | cfssljson -bare kube-proxy

#移动pem
mkdir ./kubernetes
cp *.pem ./kubernetes/
# 删除pem
rm -rf *.pem
# 删除csr
rm -rf *.csr
# 删除json
# rm -rf *.json

# 总的证书概览：
#
# etcd：使用 ca.pem、kubernetes-key.pem、kubernetes.pem；
# kube-apiserver：使用 ca.pem、kubernetes-key.pem、kubernetes.pem；
# kubelet：使用 ca.pem；
# kube-proxy：使用 ca.pem、kube-proxy-key.pem、kube-proxy.pem；
# kubectl：使用 ca.pem、admin-key.pem、admin.pem；

# 证书后缀说明
#
# 证书：.crt, .pem
# 私钥：.key
# 证书请求：.csr
