#!/bin/bash

IP=10.10.2.141
PORT=6443
SSLDIR=etc/ssl/kube

echo $IP:$PORT
echo $SSLDIR

function kubeconfig() {

    # 设置kubectl的kubeconfig（admin.conf）
    kubectl config set-cluster kubernetes --certificate-authority=/$SSLDIR/ca.pem   --embed-certs=true --server=https://$IP:$PORT   --kubeconfig=admin.conf
    # 设置客户端认证参数
    kubectl config set-credentials kubernetes-admin  --client-certificate=/$SSLDIR/admin.pem --embed-certs=true --client-key=/$SSLDIR/admin-key.pem --kubeconfig=admin.conf
    # 设置上下文参数
    kubectl config set-context kubernetes-admin@kubernetes  --cluster=kubernetes   --user=kubernetes-admin  --kubeconfig=admin.conf
    # 设置默认上下文
    kubectl config use-context kubernetes-admin@kubernetes --kubeconfig=admin.conf

}

function bootstrap() {
#cd /etc/kubernetes/

export BOOTSTRAP_TOKEN=$(head -c 16 /dev/urandom | od -An -t x | tr -d ' ')
export KUBE_APISERVER="https://$IP:$PORT"
echo "Token: ${BOOTSTRAP_TOKEN}"

# 生成token文件
cat > token.csv <<EOF
${BOOTSTRAP_TOKEN},kubelet-bootstrap,10001,"system:kubelet-bootstrap"
EOF

#设置集群参数
kubectl config set-cluster kubernetes  --certificate-authority=/$SSLDIR/ca.pem --embed-certs=true  --server=${KUBE_APISERVER}  --kubeconfig=bootstrap.kubeconfig
# 设置客户端认证参数
kubectl config set-credentials kubelet-bootstrap  --token=${BOOTSTRAP_TOKEN}   --kubeconfig=bootstrap.kubeconfig
# 设置上下文参数
kubectl config set-context default --cluster=kubernetes --user=kubelet-bootstrap --kubeconfig=bootstrap.kubeconfig
# 设置默认上下文
kubectl config use-context default --kubeconfig=bootstrap.kubeconfig
}

function proxy() {
#设置集群参数
kubectl config set-cluster kubernetes --certificate-authority=/$SSLDIR/ca.pem --embed-certs=true --server=${KUBE_APISERVER}  --kubeconfig=kube-proxy.kubeconfig
# 设置客户端认证参数
kubectl config set-credentials kube-proxy --client-certificate=/$SSLDIR/kube-proxy.pem --client-key=/$SSLDIR/kube-proxy-key.pem --embed-certs=true --kubeconfig=kube-proxy.kubeconfig
# 设置上下文参数
kubectl config set-context default --cluster=kubernetes  --user=kube-proxy  --kubeconfig=kube-proxy.kubeconfig
# 设置默认上下文
kubectl config use-context default --kubeconfig=kube-proxy.kubeconfig
}

function printhelp() {

echo "kubeconfig.sh生成kubeconfig"
echo "创建kubeconfig"
echo "    sh kubeconfig.sh kubeconfig"
echo "创建bootstrap"
echo "    sh kubeconfig.sh bootstrap"
echo "创建proxy"
echo "    sh kubeconfig.sh proxy"
echo "查看帮助"
echo "    sh kubeconfig.sh help | h"

}
case $1 in
    kubeconfig )
        echo "Create kubeconfig"
	kubeconfig
        ;;
    bootstrap )
        echo "Create bootstrap.kubeconfig"
	bootstrap
	;;
    proxy )
        echo "Create kube-proxy.kubeconfig"
	proxy
	;;
    help | h)
#        echo "help"
	printhelp
        ;;
    * )
#        echo "*help"
	printhelp
        ;;
esac

