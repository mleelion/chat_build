# 生成kubeconfig

## 生成使用kubeconfig

```
sh kubeconfig.sh
```