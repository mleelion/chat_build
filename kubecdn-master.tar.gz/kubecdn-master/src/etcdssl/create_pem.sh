#!/bin/bash

function createca(){
# cfssl print-defaults config > ca-config.json
# cfssl print-defaults csr > ca-csr.json

# 会在当前目录下生成如下文件 ca-key.pem ca.csr ca.pem
cfssl gencert -initca ca-csr.json | cfssljson -bare ca -
}

function createserver(){
# 生成server端证书
# cfssl print-defaults csr > server.json

# 接下来生成server端证书以及private key 将会生成如下文件：server-key.pem server.csr server.pem
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=server server.json | cfssljson -bare server
}

function createmember(){
# 生成peer certificate

# 得到如下文件：member1-key.pem member1.csr member1.pem
# cfssl print-defaults csr > member1.json
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=peer member1.json | cfssljson -bare member1

# 得到如下文件：member2-key.pem member2.csr member2.pem
# cfssl print-defaults csr > member2.json
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=peer member2.json | cfssljson -bare member2

# 得到如下文件：member3-key.pem member3.csr member3.pem
# cfssl print-defaults csr > member3.json
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=peer member3.json | cfssljson -bare member3
}

function createclient(){
# 生成 client certificate 
# 将会得到如下文件: client-key.pem client.csr client.pem
# cfssl print-defaults csr > client.json
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=client client.json | cfssljson -bare client
}

function deletecsr(){
# 删除 csr文件
rm -rf *.csr
}

function deletejson(){
# 删除 *.json文件
echo "Delete Json"
# rm -rf *.json
}

function deletepem(){
# 删除 *.pem 文件
 rm -rf *.pem
}

function printhelp(){
echo "help"
}
case $1 in
    all )
        mkdir ./etcd
	createca
	createserver
	createmember
	createclient
	mv *.pem ./etcd/
	;;
    delcsr )
	deletecsr
	;;
    delpem )
	deletepem
	;;
    deljson )
	deletejson
	;;
    help | *)
	printhelp
	;;
	
esac
